using System;
using System.Collections.Generic;
using Eto.Forms;
using Eto.Drawing;

namespace Lan_chat_client
{
	public delegate void Delegate();

	public sealed class Gui : Form
	{
		public event EventHandler<RequestLogoneventArgs> InitLogon;
		public event EventHandler<RequestMessageeventArgs> SendMessage;

		public event Delegate RefreshServers;
		public event Delegate Disconnect;

		private ListBox _rooms;
		private ListBox _messageList;
		private Label _ip;


		private readonly TabPage _chatTab;
		private readonly TabPage _serversTab;


		//constructor

		public Gui()
		{
			Title = "LAN-chat";
			ClientSize = new Size(800, 600);
			Resizable = false; //gui was not designed with scaling in mind

			var tabs = new TabControl();

			_serversTab = new TabPage { Text = "Servers", Content = Init_Search() };
			tabs.Pages.Add(_serversTab);

			_chatTab = new TabPage { Text = "Chat", Content = Init_chat(), Enabled = false };
			tabs.Pages.Add(_chatTab);

			Menu = Init_Bar();

			Icon = Icon.FromResource("Lan_chat_client.Resources.chat_logo.ico");
			Content = tabs;
			Request_Refresh_List(null, null);
		}

		//init methods

		private Control Init_chat()
		{
			TableLayout items;

			TextBox _messageInput = new()
			{
				PlaceholderText = "Type here..."
			};
			_messageInput.KeyDown += Request_send_message;

			_messageList = new ListBox();
			_ip = new Label();


			items = new TableLayout()
			{
				Padding = 20,
				Spacing = new Size(5, 5),
				Rows =
				{
					new TableRow(_ip),
					new TableRow(_messageList) {ScaleHeight = true},
					new TableRow(_messageInput)
				}
			};

			return items;
		}

		private MenuBar Init_Bar()
		{
			var q_app = new ButtonMenuItem { Text = "Quit App" };
			var q_room = new ButtonMenuItem { Text = "Quit Room" };

			q_app.Click += Quit_app;
			q_room.Click += Quit_room;

			MenuBar menu = new()
			{
				Items =
				{
					new ButtonMenuItem
					{
						Text = "&File",
						Items =
						{
							q_app,
							q_room
						}
					}
				}
			};
			return menu;
		}

		private Control Init_Search()
		{
			TableLayout items;
			_rooms = new ListBox();
			_rooms.Activated += Request_Logon;
			TextBox _manual_ip = new()
			{
				PlaceholderText = "Enter an ip manually here if it does not show up in the list."
			};
			_manual_ip.KeyDown += Request_Manual_Logon;

			Button refresh = new() { Text = "Refresh server list" };
			refresh.Click += Request_Refresh_List;

			items = new TableLayout()
			{
				Padding = 20,
				Spacing = new Size(5, 5),
				Rows =
				{
					new TableRow(_rooms) {ScaleHeight = true},
					new TableRow(_manual_ip),
					new TableRow(refresh),
				}
			};

			return items;
		}

		//interaction methods

		private void Quit_app(object sender, EventArgs e)
		{
			DialogResult result = MessageBox.Show
			(
				"Are you sure you want to quit?",
				"Quit",
				MessageBoxButtons.YesNo,
				MessageBoxType.Question
			);

			if (result.Equals(DialogResult.Yes))
			{
				Disconnect?.Invoke();
				Application.Instance.Quit();
			}
		}

		public void Quit_room(object sender, EventArgs e)
		{
			if (!(e == null))
			{
				Disconnect?.Invoke();
			}
			Console.WriteLine("killing");
			_chatTab.Enabled = false;
			_serversTab.Enabled = true;
			_messageList.DataStore = null;
			_ip.Text = "DISCONNECTED";

		}

		private void Request_send_message(object sender, KeyEventArgs e)
		{
			if (e.Key.Equals(Keys.Enter))
			{
				TextBox _messageInput = (TextBox)sender;
				SendMessage?.Invoke(this, new RequestMessageeventArgs { message = _messageInput.Text });
				_messageInput.Text = "";
			}
		}

		//request methods (ask program to do logic stuff via event)

		private void Request_Logon(object sender, EventArgs e)
		{
			InitLogon?.Invoke(this, new RequestLogoneventArgs { selected = _rooms.SelectedIndex });
		}

		private void Request_Manual_Logon(object sender, KeyEventArgs e)
		{
			if (e.Key.Equals(Keys.Enter))
			{
				TextBox input = (TextBox)sender;
				InitLogon?.Invoke(this, new RequestLogoneventArgs { ip = input.Text });
			}
		}


		private void Request_Refresh_List(object sender, EventArgs e)
		{
			RefreshServers?.Invoke();
		}

		//ui update methods (the program logic sending updated stuff)

		public void Logon(string adress)
		{
			_chatTab.Enabled = true;
			_serversTab.Enabled = false;
			_ip.Text = $"ip: [{adress}]";
		}

		public void Refresh_List(List<string> servers)
		{
			_rooms.DataStore = servers;
		}

		public void Refresh_chat(List<string> messages)
		{
			_messageList.DataStore = messages;
		}

		//processing methods
	}
}
