﻿using System;
using System.IO;
using Eto.Forms;
using System.Net;
using System.Text;
using System.Linq;
using System.Timers;
using System.Net.Sockets;
using System.Net.Security;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

namespace Lan_chat_client
{
	//custom event args for data requests from ui
	public class RequestLogoneventArgs : EventArgs
	{
		public int selected;
		public string ip;
	}

	public class RequestMessageeventArgs : EventArgs
	{
		public string message;
	}

	public class Program
	{
		private static Gui ui;
		private static Timer refresh;
		private static SslStream stream;
		private static List<string> messages = new();
		private static readonly List<string> server_list = new();

		//remember: 8887 for chat server, 8888 for discovery

		[STAThread]
		public static void Main()
		{
			var app = new Application();

			ui = new Gui();

			refresh = new Timer { Interval = 1000 };

			refresh.Elapsed += Update_List;           //fetches messages from server

			ui.InitLogon += Try_Init_Tcp;       //handshake between client and server
			ui.RefreshServers += Try_Refresh_List; //refresh server list
			ui.SendMessage += Try_Send_Message;       //send a message to the SSL stream
			ui.Disconnect += Disconnect;   //closes connection


			app.Run(ui);
		}

		private static void Try_Init_Tcp(object sender, RequestLogoneventArgs e) //runs from logon button
		{
			string ip;
			if (! (e.ip == null)) //if manual input was used, use that one
			{
				ip = e.ip;
			}else
			{
				ip = server_list[e.selected];
			}
			try
			{
				TcpClient client = new(ip, 8887);

				stream = new SslStream
				(
					client.GetStream(),
					false,
					new RemoteCertificateValidationCallback(Validate_Cert),
					null
				);

				stream.AuthenticateAsClient(ip);

				byte[] special = { 6, 3, 7, 2 };

				stream.Write(special);

				refresh.Start();

				ui.Logon(ip);
			}
			catch (SocketException)
			{
				DialogResult result = MessageBox.Show
				(
					"Socket exception: the server no longer exists or access was denied, refresh the server list and try again, or make sure you typed in the adress correctly.",
					"Error",
					MessageBoxButtons.OK,
					MessageBoxType.Error
				);
			}
		}

		private static async void Try_Refresh_List()
		{
			await Task.Run(() =>
			{
				server_list.Clear();

				//UDP to fetch local servers/hosts, then send that data back to the ui's listbox
				UdpClient Client = new(0);
				IPEndPoint ServerEp = new(IPAddress.Any, 8888);
				byte[] RequestData = Encoding.ASCII.GetBytes("SomeRequestData");
				string ServerResponse;

				Client.Client.ReceiveTimeout = 1000;
				Client.EnableBroadcast = true;
				Client.Send(RequestData, RequestData.Length, new IPEndPoint(IPAddress.Broadcast, 8888));
				//make sure deployment is Broadcast, not any

				while (true) //looping until timeout allows the client to detect multiple servers on the same subdomain while not having to ask the user to stop searching
				{
					try
					{
						ServerResponse = Encoding.ASCII.GetString(Client.Receive(ref ServerEp));

						server_list.Add(ServerEp.Address.ToString());
					}
					catch (SocketException) //pretty much only occurs when the timeout is reached
					{
						break; //kills receiving loop on timeout
					}
				}
				Application.Instance.Invoke(() => ui.Refresh_List(server_list));

				Client.Close();
			});
		}

		private static void Try_Send_Message(object sender, RequestMessageeventArgs e)
		{
			try
			{
				byte[] data = Encoding.ASCII.GetBytes($"[{Environment.UserName}]: {e.message}");

				stream.Write(data, 0, data.Length);
			}
			catch
			{
				Disconnect();
			}
		}

		private static bool Validate_Cert(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
		{
			return true; //a terrible idea but whatever
		}

		private static void Update_List(object sender, ElapsedEventArgs e) //requests stuff from server every so often
		{
			//sends the request code with the amount of messages it has
			byte[] data = { 5, 2, 3, 1, (byte)messages.Count };
			try
			{
				stream.Write(data, 0, 5);
			}
			catch
			{
				Disconnect();
				Console.WriteLine("yeee");
				refresh.Stop();
			}

			//downloads serialized list of messages (if any), and deserializes them
			var ser = new XmlSerializer(typeof(List<string>));

			var buffer = new byte[1024]; //xml serializer cannot de-serialize directly from a network stream
			stream.Read(buffer, 0, buffer.Length);
			var ms = new MemoryStream(buffer);

			messages = messages.Concat((List<string>)ser.Deserialize(ms)).ToList();

			//update ui on main thread
			Application.Instance.Invoke(() => ui.Refresh_chat(messages));
		}

		private static void Disconnect()
		{
			try //easier than trying to check if the connection is active
			{
				messages.Clear();
				Application.Instance.Invoke(() => ui.Refresh_chat(messages));
				Application.Instance.Invoke(() => ui.Quit_room(null, null));

				refresh.Stop();

				stream.Close();
				stream.Dispose();
			}
			catch { }
		}

	}
}
