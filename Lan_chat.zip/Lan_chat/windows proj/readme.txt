this is a csproj file configured so that the program can run on windows
