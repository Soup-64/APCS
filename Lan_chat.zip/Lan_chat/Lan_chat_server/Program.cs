﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Linq;
using System.Reflection;
using System.Net.Sockets;
using System.Net.Security;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;


//note: broadcasts are being listened for on 8888, and chat servers use 8887

namespace Lan_chat_server
{
	static class Program
	{
		static readonly List<string> MessageStore = new();

		static void Main() //starts the discovery server and the chat server
		{
			Console.WriteLine("starting server...");

			Console.WriteLine("Starting the LAN discovery server...");
			Broadcast_Listenser();

			Console.WriteLine("Starting the client initializer...");
			Client_initializer();

		}

		static async void Broadcast_Listenser() //for local server discovery
		{
			await Task.Run(() =>
			{
				var Server = new UdpClient(8888);

				while (true)
				{
					IPEndPoint ClientEp = new(IPAddress.Any, 0);

					Server.Receive(ref ClientEp); //waits to recieve some data

					Console.WriteLine($"Recieved a discovery ping from {ClientEp.Address}");

					
					Server.Send(Array.Empty<byte>(), 0, ClientEp);
				}
			});
		}

		static void Client_initializer() //manages incomming connection requests
		{
			TcpListener server = new(IPAddress.Any, 8887);
			X509Certificate2 cert;

			//TODO: make new certs for deployment
			using (Stream cs = Assembly.GetExecutingAssembly().GetManifestResourceStream("Lan_chat_server.Resources.server.pfx"))
			{ //this loop extracts the cert from embedded resources
				byte[] raw = new byte[cs.Length];

				for (int i = 0; i < cs.Length; i++)
				{
					raw[i] = (byte)cs.ReadByte();
				}
				cert = new X509Certificate2(raw, "poggers!");
			}


			server.Start();

			Console.WriteLine("starting the listen loop...");

			while (true)
			{
				//listen loop

				TcpClient client = server.AcceptTcpClient(); //accepts new connection

				SslStream stream = new(client.GetStream(), false);

				Console.WriteLine($"connected to client: {client.Client.RemoteEndPoint}");

				if (client.Client.RemoteEndPoint != null)
					Client_Manager(stream, cert,
						client.Client.RemoteEndPoint.ToString()); //async loop dedicated to specific client
			}
		}

		static async void Client_Manager(SslStream other, X509Certificate cert, string ip)
		{
			await Task.Run(() =>
			{
				bool allowed = false;
				byte[] buffer = new byte[256];
				byte[] key = new byte[4];
				byte[] code = { 5, 2, 3, 1 };
				byte[] special = { 6, 3, 7, 2 }; //special code required to access server
				int i;

				other.AuthenticateAsServer(cert, clientCertificateRequired: false, checkCertificateRevocation: true);

				try
				{
					while ((i = other.Read(buffer, 0, buffer.Length)) > 0) //runs as long as the client doesn't disconnect
					{
						Array.Copy(buffer, key, 4);

						if (key.SequenceEqual(code)) //message request code
						{ //this stuff manages how many messages the client needs
						  //note that the item in the 4th slot of the buffer is the amount of messages the client currently has
							int messages_needed = MessageStore.Count - buffer[4];
							XmlSerializer ser = new(typeof(List<string>));
							if (messages_needed > 0)
							{ //serializes the part of the message list required by client and puts in in the stream
								Console.WriteLine($"sending {messages_needed} messages to {ip}");

								ser.Serialize(other, MessageStore.GetRange(buffer[4], messages_needed));
							}
							else
							{
								ser.Serialize(other, new List<string>()); //send nothing back
							}

						}
						else if (key.SequenceEqual(special))
						{ //clients have to send a special code to before the server will store messages from them
							allowed = true;
							Console.WriteLine($"{ip} has validated");
						}
						else //message store code
						{
							if (allowed) //prevents incoming messages from being stored if client is invalid
							{
								string data = Encoding.ASCII.GetString(buffer, 0, i); //convert byte to string

								Console.WriteLine($"storing message \"{data}\" from {ip}");
								MessageStore.Add(data);
							}
						}
					}
				}
				catch //ends loop if the client is closed before it does a normmal disconnect
				{
					Console.WriteLine($"Client at [{ip}] disconnected");
				}
				Console.WriteLine($"Client at [{ip}] crashed!"); //prints if client closes normally
				other.Dispose(); //disposes network stream
				GC.Collect();
				return;
			});

		}

	}
}